
    <div class="container">
        <h2 class="text-center text-success">تمت عملية الدفع بنجاح!</h2>
        
        <div class="card mt-4">
            <div class="card-header">
                تفاصيل الدفع
            </div>
            <div class="card-body">
                @if(session()->has('payment_details'))
                    @foreach(session('payment_details') as $payment)
                        <div class="mb-4 p-3 border rounded">
                            <h5>رقم الطلب: {{ $payment->payment_id }}</h5>
                            <p><strong>المنتج:</strong> {{ $payment->product_name }}</p>
                            <p><strong>الكمية:</strong> {{ $payment->quantity }}</p>
                            <p><strong>السعر:</strong> ${{ $payment->amount }}</p>
                            <p><strong>الضريبة:</strong> ${{ $payment->vat }}</p>
                            <p><strong>الإجمالي:</strong> ${{ $payment->total }}</p>
                            <p><strong>طريقة الدفع:</strong> {{ ucfirst($payment->payment_method) }}</p>
                            <p><strong>حالة الدفع:</strong> {{ ucfirst($payment->payment_status) }}</p>
                        </div>
                    @endforeach
                @else
                    <p class="text-danger">لم يتم العثور على بيانات الدفع.</p>
                @endif
            </div>
        </div>

        <div class="text-center mt-4">
            <a href="{{ route('home') }}" class="btn btn-primary">العودة إلى الصفحة الرئيسية</a>
        </div>
    </div>
